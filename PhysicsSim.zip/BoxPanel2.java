import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//same as BoxPanel but without a next button that works and moves the platform made it like this s I can add mroe levels and mechanics 
class BoxPanel2 extends JPanel implements ActionListener {
    private Box box;
    private Timer timer;
    private int clickX;
    private int clickY;
    private boolean drawingLine = false; 
    private int lineEndX;
    private int lineEndY;
    private double distanceT, angleT;
    private Rectangle platform;
    private JButton next = new JButton("Next");
    public boolean Switch = false;
    public BoxPanel2() {
        box = new Box(180, 0, 50, 50);
        add(next);
        next.addActionListener(new NextButtonListener());
        next.setVisible(false);
        addMouseListener(new MouseClickListener());
        addMouseMotionListener(new MouseClickListener());
        timer = new Timer(16, this);
        timer.start();
        
        platform = new Rectangle(500, 100, 50, 20);
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        box.draw(g);
        g.drawString("(velocity:" + distanceT + ") (angle: " + angleT + ")", 10, 20);
        g.fillRect(platform.x, platform.y, platform.width, platform.height);

        if (drawingLine) {
            drawDottedLine(g, box.getCOMX(box.x), box.getCOMY(box.y), lineEndX, lineEndY);
        }
    }

    public void actionPerformed(ActionEvent e) {
        box.update();
        
        if (box.y + box.height > getHeight()) {
            box.y = getHeight() - box.height;
            box.velocityY = 0;
            box.x = 0; 
            box.velocityX = 0;
        }
        if (box.x + box.width > getWidth()) {
            box.x = getWidth() - box.width;
            box.velocityX *= -1;
        }
        if (box.x < 0) {
            box.x = 0;
            box.velocityX = 0;
        }

        checkCollision(); // Check for collision with the platform

        repaint();
    }

    private void checkCollision() {
        Rectangle boxBounds = new Rectangle(box.x, box.y, box.width, box.height);
        
        if (boxBounds.intersects(platform)) {
            // Check if the box is coming from above
            if (box.y + box.height - box.velocityY <= platform.y) {
                box.y = platform.y - box.height;
                next.setVisible(true);
                box.velocityY = 0; 
                box.velocityX = 0;
            }
            else if (box.y < platform.y + platform.height) {
                if (box.x < platform.x + platform.width && box.x + box.width > platform.x) {
                    box.velocityX *= -1; // Stop horizontal movement if hitting the sides
                }
                else if (box.y + box.height > platform.y) {
                    box.velocityY *= -1; // Reverse vertical movement if hitting the bottom
                }
            }
        }
    }

    private void drawDottedLine(Graphics g, double x1, double y1, double x2, double y2) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.BLACK);

        double distance = Math.hypot(x2 - x1, y2 - y1);
        double angle = Math.atan2(y2 - y1, x2 - x1);

        int dotSpacing = (int) (10 + (distance / 20));
        int dotSize = 5;

        for (int i = 0; i < distance; i += dotSpacing) {
            int x = (int) (x1 + i * Math.cos(angle));
            int y = (int) (y1 + i * Math.sin(angle));
            g2d.drawOval(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
        }
    }

    private class MouseClickListener extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            clickX = e.getX();
            clickY = e.getY();
            drawingLine = true;
            lineEndX = clickX;
            lineEndY = clickY;
        }

        public void mouseReleased(MouseEvent e) {
            drawingLine = false;
            double distanceX = lineEndX - box.getCOMX(box.x);
            double distanceY = box.getCOMY(box.y) - lineEndY;
            distanceT = (Math.hypot(distanceX, distanceY)) / 50.00;
            angleT = Math.atan2(distanceX, distanceY);

            box.velocityY = -distanceY / 50;
            box.velocityX = distanceX / 50;
            repaint();
        }

        public void mouseDragged(MouseEvent e) {
            double distanceX = lineEndX - box.getCOMX(box.x);
            double distanceY = box.getCOMY(box.y) - lineEndY;
            distanceT = (Math.hypot(distanceX, distanceY)) / 50.00;
            angleT = 180 * (Math.atan2(distanceX, distanceY)) / (Math.PI);
            angleT = Math.abs(angleT - 90);
            if (angleT > 90) {
                angleT = Math.abs(angleT - 180);
            }

            lineEndX = e.getX();
            lineEndY = e.getY();
            repaint();
        }
    }
    private class NextButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Switch = true;
        }
    }
}