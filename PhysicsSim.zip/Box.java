import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//class for the box that we are launching 
class Box {
    //components of the block to integrate physics into the gmae
    int x, y;
    int width, height;
    double velocityY;
    double accelerationY;
    double velocityX;
    double accelerationX;
    public Box(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.velocityY = 0;
        this.accelerationY = 9.8 / 60; 
    }
    //updates the physics atributes adds accerleration to velocity and velocity to x since velocity is the derrivitive of x and accleration is the second derrivitive of x 
    public void update() {
        velocityY += accelerationY; 
        y += velocityY; 
        velocityX += accelerationX;     
        x += velocityX;              
    }
    //draws the rectangle everytime to update the screen
    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, width, height);
    }
    //accsesor methods for the level classes 
    public double getCOMY(int y) {
        return y + (height / 2.0);
    }

    public double getCOMX(int x) {
        return x + (width / 2.0);
    }
    
}
