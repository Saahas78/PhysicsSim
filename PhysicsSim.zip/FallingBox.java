import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/* 

Devoloper: Saahas Matlapudi

Description:
This game is launching a block at a certain angle and velocity to go on top of a platform 

*/
//this is the running file which manages the levels 
public class FallingBox extends JFrame {
    private BoxPanel boxPanel;
    private BoxPanel2 boxPanel2;
    private CardLayout cardLayout;
    private JPanel cardPanel;
    //makes the frame to hold the panels 
    public FallingBox() {
        boxPanel = new BoxPanel();
        boxPanel2 = new BoxPanel2();
        //so I can swtich between the 2 panels 
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.add(boxPanel, "boxPanel");
        cardPanel.add(boxPanel2, "boxPanel2");

        add(cardPanel);

        setTitle("Falling Box");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    // methods to get swtich and swtich the level to show the boxpanel2 
    public boolean isSwitchLevel1() {
        return boxPanel.Switch;
    }

    public void switchToBoxPanel2() {
        cardLayout.show(cardPanel, "boxPanel2");
    }

    public static void main(String[] args) {
        //could have just moved the platform after clicking the button and resetting the box's position, but making more levels with features would be harder without this system
        FallingBox fallingBox = new FallingBox();
        while (!fallingBox.isSwitchLevel1()) {
            
            try {
                Thread.sleep(100); // so the game does not crash and uses less recources
            } catch (InterruptedException e) {
                e.printStackTrace();
            } 
        }
        fallingBox.switchToBoxPanel2();//swtiches the level 
    }
}