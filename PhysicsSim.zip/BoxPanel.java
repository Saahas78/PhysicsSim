import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//level 1
class BoxPanel extends JPanel implements ActionListener {
    private Box box;
    private Timer timer;
    private int clickX;
    private int clickY;
    private boolean drawingLine = false; 
    private int lineEndX;
    private int lineEndY;
    private double distanceT, angleT;
    private Rectangle platform; // declare it here so we can use it in all methods globally 
    private JButton next = new JButton("Next"); //button that is invisible until box lands on platform 
    // so you cant accedietily click it 
    public boolean Switch = false; //variabe that tracks when to swtich levels 
    public BoxPanel() {
        box = new Box(180, 0, 50, 50);
        add(next);
        next.setEnabled(false);
        //adding mouse and button listeners 
        next.addActionListener(new NextButtonListener());
        next.setVisible(false);
        addMouseListener(new MouseClickListener());
        addMouseMotionListener(new MouseClickListener());
        timer = new Timer(16, this); //this makes the game fun at 60 frames  calls 60 times in 1 second 
        timer.start();// repeats the timer call
        
        platform = new Rectangle(900, 200, 100, 20);
    }
    //updates the game draws line, box,platform and the string for veolocity and angle
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        box.draw(g);
        g.drawString("(velocity:" + distanceT + ") (angle: " + angleT + ")", 10, 20);
        g.fillRect(platform.x, platform.y, platform.width, platform.height);

        if (drawingLine) {
            drawDottedLine(g, box.getCOMX(box.x), box.getCOMY(box.y), lineEndX, lineEndY);
        }
    }
    //gets called everytime the tyimer is called and updates the game also runs the check colloison method and repaints to update the visuals 
    public void actionPerformed(ActionEvent e) {
        box.update();
        //resets the box's postion to 0 and makes it not move if it hits the floor
        if (box.y + box.height > getHeight()) {
            box.y = getHeight() - box.height;
            box.velocityY = 0;
            box.x = 0; 
            box.velocityX = 0;
        }
        //when hits the wall it will bounce back with the same velocity but negitive x velcoity does not change since gravity dose not effect it
        if (box.x + box.width > getWidth()) {
            box.x = getWidth() - box.width;
            box.velocityX *= -1;
        }
        //same for the left wall
        if (box.x < 0) {
            box.x = 0;
            box.velocityX = 0;
        }

        checkCollision(); // Check for collision with the platform

        repaint();//updates visuals 
    }

    //checks for collision between box and platform 
    private void checkCollision() {
        //the box's hit box 
        Rectangle boxBounds = new Rectangle(box.x, box.y, box.width, box.height);
        
        if (boxBounds.intersects(platform)) {
            // Check if the box is coming from above
            if (box.y + box.height - box.velocityY <= platform.y) {
                box.y = platform.y - box.height;
                next.setVisible(true);
                next.setEnabled(true);// sets the button to contenue to the next level to true so you can see it
                box.velocityY = 0; 
                box.velocityX = 0;
            }
            //if it does not come from above
            else if (box.y < platform.y + platform.height) {
                if (box.x < platform.x + platform.width && box.x + box.width > platform.x) {
                    box.velocityX *= -1; // Stop horizontal movement if hitting the sides
                }
                else if (box.y + box.height > platform.y) {
                    box.velocityY *= -1; // Reverse vertical movement if hitting the bottom
                }
            }
        }
    }
    // this is how the line that you use to launch the box is made
    private void drawDottedLine(Graphics g, double x1, double y1, double x2, double y2) {
        Graphics2D g2d = (Graphics2D) g;//more methods 
        g2d.setColor(Color.BLACK);

        //get the distance in a stright line from the mouse point and from the cented of the box also getting the angle to know where to draw the line 
        double distance = Math.hypot(x2 - x1, y2 - y1);
        double angle = Math.atan2(y2 - y1, x2 - x1);
        //this makes it so that the farther out you go the more streathed the line looks and is important for visualiseng the icrease in velocity 
        int dotSpacing = (int) (10 + (distance / 20));
        int dotSize = 5;
        //for loop that makes the line using trig 
        for (int i = 0; i < distance; i += dotSpacing) {
            int x = (int) (x1 + i * Math.cos(angle));
            int y = (int) (y1 + i * Math.sin(angle));
            g2d.drawOval(x - dotSize / 2, y - dotSize / 2, dotSize, dotSize);
        }
    }
    //this is how the program knows when the user is clikcing the mouse or releasing it 
    private class MouseClickListener extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            clickX = e.getX();
            clickY = e.getY();
            drawingLine = true;
            lineEndX = clickX;
            lineEndY = clickY;
        }
        //calculates velocity and applies it to the box
        public void mouseReleased(MouseEvent e) {
            drawingLine = false;
            double distanceX = lineEndX - box.getCOMX(box.x);
            double distanceY = box.getCOMY(box.y) - lineEndY;
            distanceT = (Math.hypot(distanceX, distanceY)) / 50.00;
            angleT = Math.atan2(distanceX, distanceY);

            box.velocityY = -distanceY / 50;
            box.velocityX = distanceX / 50;
            repaint();
        }
        // gets the angle and shows it 
        public void mouseDragged(MouseEvent e) {
            double distanceX = lineEndX - box.getCOMX(box.x);
            double distanceY = box.getCOMY(box.y) - lineEndY;
            distanceT = (Math.hypot(distanceX, distanceY)) / 50.00;
            angleT = 180 * (Math.atan2(distanceX, distanceY)) / (Math.PI);
            angleT = Math.abs(angleT - 90);
            if (angleT > 90) {
                angleT = Math.abs(angleT - 180);
            }

            lineEndX = e.getX();
            lineEndY = e.getY();
            repaint();
        }
    }
    //just for the button to get to the next level 
    private class NextButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            Switch = true;
        }
    }
}